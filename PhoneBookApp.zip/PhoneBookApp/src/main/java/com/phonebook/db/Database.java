package com.phonebook.db;
import java.sql.*;
public class Database {
    private static final String URL="jdbc:sqlite:phonebook.db";
    public static Connection getConnection() throws SQLException { return DriverManager.getConnection(URL); }
    public static void initialize() throws SQLException {
        try(Connection c=getConnection(); Statement s=c.createStatement()){
            s.executeUpdate("PRAGMA foreign_keys = ON");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS groups (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS contacts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL UNIQUE, email TEXT, type TEXT NOT NULL, group_id INTEGER, FOREIGN KEY(group_id) REFERENCES groups(id) ON DELETE SET NULL)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS call_log (id INTEGER PRIMARY KEY AUTOINCREMENT, contact_name TEXT NOT NULL, phone TEXT NOT NULL, call_type TEXT NOT NULL, call_time TEXT NOT NULL)");
            s.executeUpdate("INSERT OR IGNORE INTO groups(name) VALUES ('Family'),('Friends'),('Work')");
        }
    }
}
