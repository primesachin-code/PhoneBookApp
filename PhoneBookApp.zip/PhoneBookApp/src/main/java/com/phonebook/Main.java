package com.phonebook;
import com.phonebook.db.Database;import com.phonebook.ui.MainFrame;import javax.swing.*;
public class Main { public static void main(String[] args){try{Database.initialize();SwingUtilities.invokeLater(()->new MainFrame().setVisible(true));}catch(Exception e){JOptionPane.showMessageDialog(null,"Could not start application: "+e.getMessage(),"Startup error",JOptionPane.ERROR_MESSAGE);}} }
