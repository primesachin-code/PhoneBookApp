package com.phonebook.model;

public abstract class Contact implements Searchable {
    private int id; private String name, phone, email, groupName;
    protected Contact(int id, String name, String phone, String email, String groupName) {
        this.id=id; this.name=name; this.phone=phone; this.email=email; this.groupName=groupName;
    }
    public int getId(){return id;} public void setId(int id){this.id=id;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getGroupName(){return groupName;} public void setGroupName(String v){groupName=v;}
    public abstract String getType();
    @Override public boolean matches(String q){String s=q==null?"":q.trim().toLowerCase(); return name.toLowerCase().contains(s)||phone.toLowerCase().contains(s);}
    @Override public String toString(){return name+" ("+phone+")";}
}
