package com.phonebook.model;
public class BusinessContact extends Contact {
    public BusinessContact(int id,String name,String phone,String email,String group){super(id,name,phone,email,group);}
    @Override public String getType(){return "Business";}
}
