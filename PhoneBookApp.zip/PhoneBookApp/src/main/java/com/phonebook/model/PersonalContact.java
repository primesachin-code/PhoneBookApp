package com.phonebook.model;
public class PersonalContact extends Contact {
    public PersonalContact(int id,String name,String phone,String email,String group){super(id,name,phone,email,group);}
    @Override public String getType(){return "Personal";}
}
