package com.phonebook.model;

public interface Searchable {
    boolean matches(String query);
}
