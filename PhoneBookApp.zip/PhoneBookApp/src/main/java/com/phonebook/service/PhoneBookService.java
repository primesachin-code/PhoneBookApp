package com.phonebook.service;
import com.phonebook.db.Database; import com.phonebook.model.*; import java.sql.*; import java.util.*;
public class PhoneBookService {
    public List<Contact> contacts(String search) throws SQLException {
        List<Contact> out=new ArrayList<>(); String sql="SELECT c.*, COALESCE(g.name,'') group_name FROM contacts c LEFT JOIN groups g ON c.group_id=g.id WHERE lower(c.name) LIKE ? OR c.phone LIKE ? ORDER BY c.name";
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(sql)){String q="%"+(search==null?"":search.trim().toLowerCase())+"%";p.setString(1,q);p.setString(2,q);try(ResultSet r=p.executeQuery()){while(r.next()){int id=r.getInt("id");String n=r.getString("name"),ph=r.getString("phone"),e=r.getString("email"),g=r.getString("group_name"),t=r.getString("type");out.add("Business".equals(t)?new BusinessContact(id,n,ph,e,g):new PersonalContact(id,n,ph,e,g));}}}return out;
    }
    public void saveContact(int id,String name,String phone,String email,String type,String group) throws Exception {
        if(name.isBlank()||phone.isBlank())throw new IllegalArgumentException("Name and phone number are required.");
        String duplicate="SELECT id FROM contacts WHERE phone=? AND id<>?";
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(duplicate)){p.setString(1,phone.trim());p.setInt(2,id);try(ResultSet r=p.executeQuery()){if(r.next())throw new DuplicateContactException("A contact with this phone number already exists.");}}
        Integer gid=null; if(group!=null&&!group.isBlank()){try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("SELECT id FROM groups WHERE name=?")){p.setString(1,group);try(ResultSet r=p.executeQuery()){if(r.next())gid=r.getInt(1);}}}
        String sql=id==0?"INSERT INTO contacts(name,phone,email,type,group_id) VALUES(?,?,?,?,?)":"UPDATE contacts SET name=?,phone=?,email=?,type=?,group_id=? WHERE id=?";
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setString(1,name.trim());p.setString(2,phone.trim());p.setString(3,email.trim());p.setString(4,type);if(gid==null)p.setNull(5,Types.INTEGER);else p.setInt(5,gid);if(id!=0)p.setInt(6,id);p.executeUpdate();}
    }
    public void deleteContact(int id)throws SQLException{try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM contacts WHERE id=?")){p.setInt(1,id);p.executeUpdate();}}
    public List<Group> groups()throws SQLException{List<Group> a=new ArrayList<>();try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM groups ORDER BY name");ResultSet r=p.executeQuery()){while(r.next())a.add(new Group(r.getInt("id"),r.getString("name")));}return a;}
    public void addGroup(String name)throws SQLException{try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO groups(name) VALUES(?)")){p.setString(1,name.trim());p.executeUpdate();}}
    public void deleteGroup(int id)throws SQLException{try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM groups WHERE id=?")){p.setInt(1,id);p.executeUpdate();}}
    public void addCall(String name,String phone,String type)throws SQLException{try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO call_log(contact_name,phone,call_type,call_time) VALUES(?,?,?,datetime('now','localtime'))")){p.setString(1,name);p.setString(2,phone);p.setString(3,type);p.executeUpdate();}}
    public List<CallLog> calls()throws SQLException{List<CallLog>a=new ArrayList<>();try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM call_log ORDER BY id DESC");ResultSet r=p.executeQuery()){while(r.next())a.add(new CallLog(r.getInt("id"),r.getString("contact_name"),r.getString("phone"),r.getString("call_type"),r.getString("call_time")));}return a;}
}
