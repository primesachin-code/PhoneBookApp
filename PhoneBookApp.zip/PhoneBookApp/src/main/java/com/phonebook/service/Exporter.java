package com.phonebook.service;
import com.phonebook.db.Database; import java.io.*; import java.sql.*;
public class Exporter {
 public static void export(String table,File file)throws Exception{
  String sql=switch(table){case "contacts"->"SELECT c.name,c.phone,c.email,c.type,COALESCE(g.name,'') AS group_name FROM contacts c LEFT JOIN groups g ON c.group_id=g.id";case "groups"->"SELECT name FROM groups";case "call_log"->"SELECT contact_name,phone,call_type,call_time FROM call_log";default->throw new IllegalArgumentException("Unsupported export");};
  try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(sql);ResultSet r=p.executeQuery();PrintWriter w=new PrintWriter(new FileWriter(file))){ResultSetMetaData m=r.getMetaData();for(int i=1;i<=m.getColumnCount();i++){if(i>1)w.print(',');w.print(quote(m.getColumnName(i)));}w.println();while(r.next()){for(int i=1;i<=m.getColumnCount();i++){if(i>1)w.print(',');w.print(quote(r.getString(i)));}w.println();}}
 }
 private static String quote(String s){if(s==null)s="";return "\""+s.replace("\"","\"\"")+"\"";}
}
